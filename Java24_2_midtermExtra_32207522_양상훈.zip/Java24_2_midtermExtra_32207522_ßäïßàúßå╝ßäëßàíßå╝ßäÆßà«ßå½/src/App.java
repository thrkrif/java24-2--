public class App {
    public static void main(String[] args) throws Exception {
        // new template.MainTest();
        // new decorator.MainTest();
        // new factorybuilder.MainTest();
        // new strategy.MainTest();
        new observer.MainTest();
    }
}
